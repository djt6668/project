package cn.kevinlu98.exception;

/**
 * Author: Mr丶冷文
 * Date: 2022/10/15 20:01
 * Email: kevinlu98@qq.com
 * Description:
 */
public class LWNotFindException extends Exception {
}
